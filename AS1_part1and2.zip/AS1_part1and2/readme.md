All code submissions are in the .ipynb format. 
Ensure an internet connection to download necessary datasets when executing the codes.

